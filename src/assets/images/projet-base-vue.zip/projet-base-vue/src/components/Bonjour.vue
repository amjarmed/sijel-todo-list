<script setup lang="ts">
  const props = defineProps<{nom?: string}>()
</script>

<template>
  <p>Bonjour {{props.nom}}!</p>
</template>

<style scoped>

</style>