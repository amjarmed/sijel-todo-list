<script setup lang="ts">
import Bonjour from '@/components/Bonjour.vue';

</script>

<template>
  <h1>Projet de base Vue</h1>
  <bonjour></bonjour>
</template>

<style scoped>
h1 {
  font-family: Arial, sans-serif;
}
</style>